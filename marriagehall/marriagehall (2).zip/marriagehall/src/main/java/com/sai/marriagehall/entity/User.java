package com.sai.marriagehall.entity;

public class User {

}
