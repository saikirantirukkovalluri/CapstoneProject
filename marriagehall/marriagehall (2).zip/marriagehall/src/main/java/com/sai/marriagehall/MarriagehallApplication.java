package com.sai.marriagehall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarriagehallApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarriagehallApplication.class, args);
	}

}
